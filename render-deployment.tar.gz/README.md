# LA PASION ON TOP

La pasión is a Laravel point-of-sale application with inventory, staff and customer accounts, pickup orders, sales history, and printable receipts.

Built with Laravel 13, Blade, Eloquent, MySQL/MariaDB, native CSS, and JavaScript.

[Setup](#setup) · [TFA8 resource controllers and authentication](#tfa8-resource-controllers-and-authentication) · [Sign in and registration](#sign-in-and-registration) · [Staff workspace](#staff-workspace) · [Customer account and shopping](#customer-account-and-shopping)

## Setup

Requirements: PHP 8.3 or newer, Composer, Node.js, and a supported SQLite, MySQL, MariaDB, or PostgreSQL database.

```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed
npm install
npm run build
php artisan serve
```

Configure the database connection in `.env` before running the migrations. The optional bootstrap staff account is created only when `BOOTSTRAP_ADMIN_USERNAME` and `BOOTSTRAP_ADMIN_PASSWORD` are configured.

Run the automated checks with:

```bash
php artisan test
```

## TFA8 resource controllers and authentication

- Customer management uses `Route::resource('customers', CustomerController::class)`.
- Staff user management uses `Route::resource('users', UserController::class)`.
- Both resource groups are protected by Laravel's `auth:web` middleware.
- Laravel Breeze provides the staff login, registration, rate limiting, secure session regeneration, and logout flow.
- Customer authentication remains on its separate `customer` guard.
- Database migrations, factories, and the idempotent database seeder are included.

## Desktop screenshot gallery

40 desktop captures at a 1440-pixel viewport. The records shown are fictional sample data from a separate demonstration database. Mobile layouts are checked separately; this gallery contains desktop views only.

## Sign in and registration

### Staff sign in

![Staff sign in](public/screenshots/desktop/staff-login.png)

### Customer sign in

![Customer sign in](public/screenshots/desktop/customer-login.png)

### Customer registration

![Customer registration](public/screenshots/desktop/customer-register.png)

### Registration validation and retained form values

![Registration validation and retained form values](public/screenshots/desktop/registration-validation.png)

## Staff workspace

### Sales counter with a selected product and customer

![Sales counter with a selected product and customer](public/screenshots/desktop/staff-sales-counter.png)

### Product inventory

![Product inventory](public/screenshots/desktop/staff-products.png)

### Add a product

![Add a product](public/screenshots/desktop/staff-product-create.png)

### Edit a product and its image

![Edit a product and its image](public/screenshots/desktop/staff-product-edit.png)

### Archived products

![Archived products](public/screenshots/desktop/staff-products-archived.png)

### Customer directory and login access

![Customer directory and login access](public/screenshots/desktop/staff-customers.png)

### Add a customer and enable online access

![Add a customer and enable online access](public/screenshots/desktop/staff-customer-create.png)

### Edit customer details or reset login credentials

![Edit customer details or reset login credentials](public/screenshots/desktop/staff-customer-edit.png)

### Customers with paused login access

![Customers with paused login access](public/screenshots/desktop/staff-customers-paused.png)

### Deleted customers and restoration

![Deleted customers and restoration](public/screenshots/desktop/staff-customers-deleted.png)

### Staff accounts and profile pictures

![Staff accounts and profile pictures](public/screenshots/desktop/staff-directory.png)

### Add a staff member

![Add a staff member](public/screenshots/desktop/staff-create.png)

### Edit staff details and avatar

![Edit staff details and avatar](public/screenshots/desktop/staff-edit.png)

### Sales history and filters

![Sales history and filters](public/screenshots/desktop/staff-sales-history.png)

### Staff sales receipt

![Staff sales receipt](public/screenshots/desktop/staff-receipt.png)

### Pending customer orders

![Pending customer orders](public/screenshots/desktop/staff-orders-pending.png)

### Review an order before confirming payment

![Review an order before confirming payment](public/screenshots/desktop/staff-order-pending.png)

### Completed order with linked receipts

![Completed order with linked receipts](public/screenshots/desktop/staff-order-completed.png)

### Completed customer orders

![Completed customer orders](public/screenshots/desktop/staff-orders-completed.png)

### Cancelled order details

![Cancelled order details](public/screenshots/desktop/staff-order-cancelled.png)

### Print-ready receipt layout

![Print-ready receipt layout](public/screenshots/desktop/staff-receipt-print.png)

### Product image preview before saving

![Product image preview before saving](public/screenshots/desktop/staff-product-upload.png)

### Payment confirmation dialog

![Payment confirmation dialog](public/screenshots/desktop/staff-payment-confirmation.png)

### Customer login and record actions

![Customer login and record actions](public/screenshots/desktop/staff-customer-actions.png)

### Product validation and retained values

![Product validation and retained values](public/screenshots/desktop/staff-product-validation.png)

## Customer account and shopping

### Product catalog with prices and availability

![Product catalog with prices and availability](public/screenshots/desktop/customer-shop.png)

### Product search and in-stock filtering

![Product search and in-stock filtering](public/screenshots/desktop/customer-shop-search.png)

### Empty shopping cart

![Empty shopping cart](public/screenshots/desktop/customer-cart-empty.png)

### Customer order history

![Customer order history](public/screenshots/desktop/customer-orders.png)

### Pending pickup order and cancellation

![Pending pickup order and cancellation](public/screenshots/desktop/customer-order-pending.png)

### Completed order and product receipts

![Completed order and product receipts](public/screenshots/desktop/customer-order-completed.png)

### Cancelled customer order

![Cancelled customer order](public/screenshots/desktop/customer-order-cancelled.png)

### Private purchase history and receipt access

![Private purchase history and receipt access](public/screenshots/desktop/customer-purchases.png)

### Customer receipt

![Customer receipt](public/screenshots/desktop/customer-receipt.png)

### Customer profile and password settings

![Customer profile and password settings](public/screenshots/desktop/customer-account.png)

### Cart with editable quantities and pickup checkout

![Cart with editable quantities and pickup checkout](public/screenshots/desktop/customer-cart.png)
